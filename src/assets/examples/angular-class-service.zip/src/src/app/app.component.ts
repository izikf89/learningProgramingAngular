import { Component } from '@angular/core';

export class MyClass  { text; }; 

@Component({
    selector: 'child', 
    template: '<h1>chilt text: {{ text }}</h1>',
}) export class ChildComponent {
    text;

    constructor(myClass: MyClass) {
      this.text = myClass.text;
    }
}

@Component({
    selector: 'my-app', 
    template: `<child></child>`,
}) export class AppComponent {
    constructor(myClass: MyClass) {
      myClass.text = "parent change that!";      
    }
}