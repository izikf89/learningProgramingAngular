import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent, MyClass, ChildComponent } from './app.component';

@NgModule({
    declarations: [ AppComponent, ChildComponent ],
    imports: [ BrowserModule ],
    providers: [ MyClass ],
    bootstrap: [ AppComponent ]
})
export class AppModule { }