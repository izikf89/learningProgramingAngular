import { Component, Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[colorRed]' 
})
export class ColorRed {
  constructor(private elm: ElementRef) {
    elm.nativeElement.style.color = 'red'
  }
}

@Component({
  selector: 'my-app',
  template: '<h1 colorRed >directive</h1>',
})
export class AppComponent { }