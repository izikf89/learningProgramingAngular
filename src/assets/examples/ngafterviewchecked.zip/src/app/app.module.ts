import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent, ChildApp } from './app.component';

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent, ChildApp ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
