import { Component, ViewChild } from '@angular/core';

@Component({
  selector:'child-app',
  template: `<button (click)='fun()'>child</button>`
})
export class ChildApp {
  counter = 0;
  fun() { 
    this.counter++; 
  }
}

@Component({
  selector: 'my-app',
  template: `<child-app></child-app>`
})
export class AppComponent {
  ngAfterViewChecked() {
    alert('ngAfterViewChecked listen!')
  }
}