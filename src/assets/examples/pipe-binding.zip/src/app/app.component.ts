import { Component, Pipe } from '@angular/core';

@Component({
  selector: 'my-app',
  template:`<h1> {{ value | myPipe }}</h1>
    <button (click)='fun()'>change data</button>`
})
export class AppComponent {
  value = 1;
  fun() { this.value++; }
}

@Pipe({name: 'myPipe'})
export class MyPipe   {
  transform(item){        
    return item  * 2;
  }    
}