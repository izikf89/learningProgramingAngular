import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: 
    `<input ngModel #hash>
    <h1>{{ hash.className }}`,
  styles: [ '.ng-touched { background: red }' ]
})
export class AppComponent { }