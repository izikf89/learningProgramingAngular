import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
    <select [(ngModel)]="modelName">
    <option *ngFor='let item of array' [ngValue]='item'>{{ item.key1 }}</option>
    </select>    
    <h1>{{ modelName | json }}</h1>`
})
export class AppComponent  {
  array = [{key1:"value1", key2:"value1"}, {key1:"value2", key2:"value2"}];
}