import { Component } from '@angular/core';
import { trigger, style, animate, transition } from '@angular/animations';

@Component({
  selector: 'my-app',
  template: `<button *ngIf='show' [@simple]>דוגמא</button>`,
  animations: [
    trigger('simple',[
      transition(':enter',
        animate('1s',
          style({transform: 'translateY(200%)', opacity: '1'})
        )
      ),
      transition(':leave',
        animate('1s',
          style({transform: 'translateX(200%)', opacity: '0'})
        )
      )
    ])
  ]
})
export class AppComponent  {
  show: boolean = true;
  
  ngOnInit() {
    setInterval(()=> {
      this.show = !this.show;
    } ,2000);
  }
}