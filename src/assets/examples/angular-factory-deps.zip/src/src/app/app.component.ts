import {Component, Injectable} from '@angular/core';

@Injectable()
  export class DepsService {
  text = "i deps";
}

@Injectable()
export class MyService {
  text;

  constructor(private deps: DepsService) {
    this.text = this.deps.text;
  }
}

@Component({
  selector: 'my-app', 
  template: '<h1>{{ text }}',
  providers: [DepsService,{ provide: MyService, useFactory: (deps: DepsService) => new MyService(deps), deps: [DepsService] }]
}) export class AppComponent {
  text;

  constructor(private service: MyService ) {
    this.text = this.service.text;
  }
}