import { Injectable } from '@angular/core';

@Injectable()
export class MyService {
  
  num = 1;
 
  myMethod() { 
    return ++this.num; 
  }
}