import { Component } from '@angular/core';
import { MyService } from './my-service.service';

@Component({
  selector: 'my-app',
  template: '<h1> property: {{ property }}, method: {{ method }}',
 
})
export class AppComponent  {

  constructor (private service: MyService ) {}

  property = this.service.num;
  method = this.service.myMethod();
}