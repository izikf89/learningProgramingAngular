import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent, ComponentDynamic }  from './app.component';

@NgModule({
    imports: [ BrowserModule ],
    declarations: [ 
        AppComponent,
        ComponentDynamic
    ],
    entryComponents: [ ComponentDynamic ],
    bootstrap: [ AppComponent ]
})
export class AppModule {}
