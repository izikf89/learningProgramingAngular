import {  Component, Directive, OnInit, ComponentFactoryResolver, ViewContainerRef } from '@angular/core';

@Component({ 
  selector: '', 
  template: `<h1> i am component dynamic!</h1>` 
})
export class ComponentDynamic {}

@Component({
    selector: 'my-app',
    template: `<div d-dinamic ></div>`
})
export class AppComponent {
    constructor(public vcr: ViewContainerRef, private cfr: ComponentFactoryResolver) { }
    
    ngOnInit() {
      let newComponent = this.cfr.resolveComponentFactory(ComponentDynamic);
        this.vcr.createComponent(newComponent);
    }
  
}
