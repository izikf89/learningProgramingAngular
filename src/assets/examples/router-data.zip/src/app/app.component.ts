import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActivatedRoute, Router } from '@angular/router'

@Component({
  selector: 'my-app',
  template: 
    `<a routerLink='A'>A</a>
    <a routerLink='B'>B</a>
    <router-outlet></router-outlet>`,
})
export class AppComponent  {}

@Component({
  selector: 'app-a',
  template: '<h1>A</h1>',
})
export class AComponent  {
  constructor(private route: ActivatedRoute, private router: Router ) { }
  ngOnInit() {
    this.route.data.subscribe(data => alert(data.title))
  }
}

@Component({
  selector: 'app-b',
  template: '<h1>B</h1>',
})
export class BComponent  {
    constructor(private route: ActivatedRoute, private router: Router ) { }
  ngOnInit() {
    this.route.data.subscribe(data => alert(data.title))
  }
}

const routes: Routes = [
  { path: 'A', component: AComponent, data: { title: 'data A' } },
  { path: 'B', component: BComponent, data: { title: 'data B' } },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class RootRoutingModule { }
