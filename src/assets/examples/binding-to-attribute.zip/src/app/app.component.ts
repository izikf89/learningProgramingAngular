import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1 [style.color]="colorName" >angular 5</h1>',
})
export class AppComponent  {
  colorName = 'red';
}
