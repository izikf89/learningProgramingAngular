import { Component, ViewChild } from '@angular/core';

@Component({ selector:'child-app', template:'' })
export class ChildComponent {  name = 'i am child'; }

@Component({
  selector: 'my-app',
  template: `<child-app></child-app>  {{ childValue }}`
})
export class AppComponent  {
  childValue;
  @ViewChild (ChildComponent) viewChild;
  
  ngOnInit() { 
    this.childValue = this.viewChild.name;
  }
}