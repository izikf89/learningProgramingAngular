import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: 
  `<h1 *ngIf="1 < 2" >tag 1</h1> 
  <h1 *ngIf="false" >tag 2</h1>
  <h1 *ngIf="property" >property</h1>
  <h1 *ngIf="nullValue" >null</h1>`,
})
export class AppComponent  {
  property = true;
  nullValue = null;
 }
