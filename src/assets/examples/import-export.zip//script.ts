export let myObject = 1;
 