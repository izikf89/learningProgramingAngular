import { myObject } from './script';

document.getElementById('app').innerHTML = myObject + '';
