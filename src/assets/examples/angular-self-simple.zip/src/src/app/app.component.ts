import { Component, Injectable, Self, Optional } from '@angular/core';

@Injectable()
export class Service {
  text = 'i service'
  }

@Component({
  selector: 'my-app', 
  template: `<child></child>`,
  providers: [ Service ]
}) export class AppComponent { }

@Component({
  selector: 'child', 
  template: '<h1>{{ text }}</h1>',    
}) export class Child {
  text;
  constructor( @Self() @Optional() service: Service) { 
    this.text = (service === null);
  }
}
