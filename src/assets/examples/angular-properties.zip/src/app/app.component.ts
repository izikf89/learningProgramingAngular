import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1 [style.background]="'red'">properties</h1>`,
})
export class AppComponent  { }