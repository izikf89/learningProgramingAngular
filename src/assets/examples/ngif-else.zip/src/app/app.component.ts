import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: 
  `<p *ngIf= "false; else tamplateName;" >ng-if</p>
    <h1 #tamplateName>else</h1>`,
})
export class AppComponent { }