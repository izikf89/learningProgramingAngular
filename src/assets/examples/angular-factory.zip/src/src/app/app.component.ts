import {Component, Injectable} from '@angular/core';

@Injectable()
export class MyService {
  text;

  constructor(private newText) {
    this.text = newText;
  }
}

@Component({
  selector: 'my-app', 
  template: '<h1>{{ text }}</h1>',
  providers: [{ provide: MyService, useFactory: () => new MyService('i factory') }]
}) export class AppComponent {
  text;

  constructor(private service: MyService ) {
    this.text = this.service.text;
  }
}