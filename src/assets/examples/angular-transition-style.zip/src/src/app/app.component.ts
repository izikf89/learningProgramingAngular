import { Component } from '@angular/core';
import { trigger, style, animate, transition } from '@angular/animations';

@Component({
  selector: 'my-app',
  template: `<button *ngIf='show' [@simple]>דוגמא</button>`,
  animations: [
    trigger('simple',[
      transition(':enter', [
        style({background: 'blue'}),
        animate('3s',
          style({background: 'red'})
        )
      ])      
    ])
  ]
})
export class AppComponent  {
  show: boolean = true;
  
  ngOnInit() {
    setInterval(()=> {
      this.show = !this.show;
    } ,3000);
  }
}