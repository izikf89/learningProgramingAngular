import { Component } from '@angular/core';

 @Component({
        selector: 'child-style',
        template:'<p>child</p>'
})
export class ChildStyle { }

@Component({
  selector: 'my-app',
        template: `<p>parent</p>
        <child-style></child-style>`,
        styles:['p { color: red }']
})
export class AppComponent { }