import { Component, Input } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<app-child [newAttribute]="'hello world'" ></app-child>`,
})
export class AppComponent  { }

@Component({
  selector: 'app-child',
  template: `<h1>{{ newAttribute }}</h1>`,
})
export class ChildComponent  {
  @Input() newAttribute;
}