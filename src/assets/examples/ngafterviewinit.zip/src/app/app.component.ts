import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<child-app></child-app>`
})
  export class AppComponent {
  ngOnInit() { alert('parent - ngOnInit') }
  ngAfterViewInit() { alert('parent - ngAfterViewInit') }
}

@Component({
  selector:'child-app',
  template: `<p>child</p>`
})
export class ChildApp {
  ngOnInit() { alert('child - ngOnInit') }
}