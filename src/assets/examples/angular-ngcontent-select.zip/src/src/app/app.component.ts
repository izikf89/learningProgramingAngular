import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
    <content>
      <a></a>
      <b></b>    
    </content>
  `
})
export class AppComponent {}

@Component({
  selector: 'content',
  template: `
  <ng-content select=b></ng-content>
  <ng-content select=a></ng-content>
  `,
})
export class Content {}

@Component({
  selector: 'a',
  template: '<h1>A</h1>',
  
})
export class A {}


@Component({
  selector: 'b',
  template: '<h1>B</h1>',
  
})
export class B {}