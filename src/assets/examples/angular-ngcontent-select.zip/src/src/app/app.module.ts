import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent, Content, A, B } from './app.component';

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent, Content, A, B ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
