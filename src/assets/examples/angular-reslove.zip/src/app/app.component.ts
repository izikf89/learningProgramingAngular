import { Component, NgModule, Injectable } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

@Component({
  selector: 'my-app',
  template:
    `<a routerLink='A'>A</a>
    <a routerLink='B'>B</a>
    <router-outlet></router-outlet>`,
})
export class AppComponent { }

@Component({
  selector: 'app-a',
  template: '<h1>A</h1>',
})
export class AComponent { }

@Component({
  selector: 'app-b',
  template: '<h1>B</h1>',
})
export class BComponent { }

/***** gaurd */

@Injectable()
export class serviceName {
  resolve() {
    alert('reslove play!');
    return false;
  }
}

/** router */

const routes: Routes = [
  { path: 'A', component: AComponent },
  { path: 'B', component: BComponent, resolve: [serviceName] }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class RootRoutingModule { }

