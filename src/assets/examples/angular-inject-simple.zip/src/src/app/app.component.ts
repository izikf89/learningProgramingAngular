import { Component, Inject } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1>{{ text }}</h1>`,
  providers: [{ provide: 'string', useValue: 'I service'}]
})
export class AppComponent  {
  text;
  constructor(@Inject('string') private service) { }

  ngOnInit() {
    this.text = this.service;
  }
}
