import { Component, Injector } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1>{{ text }}</h1>',
  providers: [ { provide: 'service', useValue: 'I service'}]
})
export class AppComponent  {
  text;
  constructor(private injector: Injector) {}

  ngOnInit() {
      let service = this.injector.get('service');
      this.text = service;
  } 
}
