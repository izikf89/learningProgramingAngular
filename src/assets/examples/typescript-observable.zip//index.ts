import { Subject } from 'rxjs/Subject';

class ObservableExample  {
  myHtml = 0;

  myVar;
  myObservable = new Subject();

  method() {
    this.myVar = this.myObservable.asObservable();

    setInterval(()=>this.myObservable.next(1), 1000);
    
    this.myVar.subscribe((val)=> {
      this.myHtml += val;
      document.getElementById('app').innerHTML = this.myHtml.toString();
    })
  }
}

let myClass = new ObservableExample();
myClass.method();