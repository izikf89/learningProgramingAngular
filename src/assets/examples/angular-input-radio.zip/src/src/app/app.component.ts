import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: 
    `<input value="A" [(ngModel)]="myProperty" type="radio">
     <input value="B" [(ngModel)]="myProperty" type="radio"> 
    <h1>{{ myProperty }}</h1>`,
})
export class AppComponent { 
  myProperty = "A";
}