import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<button (click)="myMethod()">press me</button>',
})
export class AppComponent  {
  myMethod() { alert() };
}
