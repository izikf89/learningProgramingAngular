import { Component, Directive } from '@angular/core';
import { NG_VALIDATORS } from '@angular/forms';

export function CustomValidation() {
  return (control) => {
    return 5 != control.value ? { customValidation: true } : null;
  };
}

@Directive({
  selector: '[CustomValidation]',
  providers: [{provide: NG_VALIDATORS, useExisting: ValidatorDirective, multi: true}]
})
export class ValidatorDirective {
  validate(control) {    
    return control ? CustomValidation()(control) : null;
  }
}

@Component({
  selector: 'my-app',
  template:
    `<input CustomValidation [(ngModel)]="modelName" #hash=ngModel > 
    <br>
    customValidation: {{ hash.errors | json }}`
})
export class AppComponent  { }