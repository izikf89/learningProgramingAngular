import { Component, Injectable, Directive, Host, Self, Optional } from '@angular/core';
  
export class Service { }

@Component({
  selector: 'child', 
  template:'<h1>{{ text }}</h1>'
}) export class Child {
  text;
  constructor(  @Optional() @Host() service: Service) { 
    this.text = service === null;
  }
}

@Component({
  selector: 'my-app', 
  template: `<child></child>`,
  viewProviders: [ Service ]

}) export class AppComponent { }