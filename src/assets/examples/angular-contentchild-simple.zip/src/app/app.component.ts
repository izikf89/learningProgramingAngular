import { Component, ContentChild } from '@angular/core';

@Component({ selector:'child-app', template:''})
export class ChildComponent { name = 'i child' }

@Component({ selector:'parent-app', template:'{{ childValue }}'})
export class ParentComponent {
  childValue
  @ContentChild (ChildComponent) contentChild;

  ngOnInit() { 
    this.childValue = this.contentChild.name;
  }
}

@Component({
  selector: 'my-app',
 template: `
  <parent-app>
     <child-app></child-app> 
  </parent-app>`
})
export class AppComponent  {}