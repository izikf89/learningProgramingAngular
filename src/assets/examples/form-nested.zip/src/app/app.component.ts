import { Component } from '@angular/core';
import { FormBuilder, Validators, FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'my-app',
  template:
  `<h1>FormGroup</h1>
    <form [formGroup]='formName' >
      <input formControlName='inputName'>
      <div formGroupName='nestedFromName' >
        <input formControlName='nstedInputName'>
      </div>                
    </form>                      
    <p> value: {{ formName.value.inputName }}</p>         
    <p> nested value: {{ formName.value.nestedFromName.nstedInputName }}</p>
    <app-FormBuilder></app-FormBuilder>
    `
})
export class AppComponent {

  constructor(private fb: FormBuilder) { }

  formName = new FormGroup({
    inputName: new FormControl("default value", [
      Validators.required,
      Validators.maxLength(15)
    ]),
     nestedFromName:  new FormGroup({
      nstedInputName: new FormControl('default value',[]
      )
     })
  })  
}

@Component({
  selector: 'app-FormBuilder',
  template:`
  <h1>FormBuilder</h1>
    <form [formGroup]='formName' >
      <input formControlName='inputName'>
      <div formGroupName='nestedFromName' >
        <input formControlName='nstedInputName'>
      </div>                
    </form>                      
    <p> value: {{ formName.value.inputName }}</p>         
    <p> nested value: {{ formName.value.nestedFromName.nstedInputName }}</p>`
})
export class FormBuilderComponent {

  constructor(private fb: FormBuilder) { }

  formName = this.fb.group({
    inputName: ['default value', Validators.required],
    nestedFromName: this.fb.group({
      nstedInputName: ['default value']
    })
  });
}