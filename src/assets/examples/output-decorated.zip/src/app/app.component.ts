import { Component, Output, EventEmitter, HostListener } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1> create event by decorated</h1> ',
})
export class AppComponent  {
  @HostListener("myEvent", ['$event'] ) myMethod(e){ 
    alert(e);
  }

  @Output() myEvent =  new EventEmitter(); 

  ngOnInit() {
    this.myEvent.emit("my first event!");  
  }
}