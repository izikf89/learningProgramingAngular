import { Component } from '@angular/core';
import { trigger, style, animate, transition, query } from '@angular/animations';

@Component({
  selector: 'my-app',
  template: `
    <div *ngIf="show" [@query]>
      <h1 >h1</h1>
      <h2 >h2</h2>
    </div>`,
  animations: [
    trigger('query',[
      transition(':enter',
        query('h1', [
          animate("1s", style({ background: "red" })),
          animate("1s", style({ background: "blue" }))
          ]
        )   
      )
    ])
  ]
})
export class AppComponent  {
  show: boolean = true;
  
  ngOnInit() {
    setInterval(()=> {
      this.show = !this.show;
      setTimeout(()=> {
        this.show = !this.show;
      }, 0);
    }, 2000);
  }
}