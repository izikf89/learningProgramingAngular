import { Component } from '@angular/core';

@Component({
  selector: 'hello',
  template: '',
})
export class HelloComponent  {
  property = 'hello';
}

@Component({
  selector: 'my-app',
  template: `
    <hello #helloHashtag ></hello>
    <h1>{{ helloHashtag.property }}</h1> `,
})
export class AppComponent  { }
