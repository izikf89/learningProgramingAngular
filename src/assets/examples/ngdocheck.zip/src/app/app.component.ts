import { Component, Directive, Input } from '@angular/core';
@Component({
  selector: 'my-app',
  template: `<button directiveListen (click)='fun()'>ng change</button>`
})
export class AppComponent   {
  counter = 0;
  fun() { 
    this.counter++ 
  }
}

@Directive({
  selector: '[directiveListen]',
})
export class DirectiveListen {
  ngDoCheck() {
    alert('ngDoCheck listen');
  }
}