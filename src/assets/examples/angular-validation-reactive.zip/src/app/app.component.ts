import { Component, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

export function CustomValidation() {
  return (control) => {
    return 5 != control.value ? { customValidation: true } : null;
  };
}

@Component({
  selector: 'my-app',
  template:`
    <form [formGroup]='formName' >
        <input formControlName='inputName'>
    </form>                      
    <p> value: {{ formName.controls.inputName.errors | json }}</p>`
})
export class AppComponent {
  formName = new FormGroup({
    inputName: new FormControl(1, [
      CustomValidation(),
    ])
  }) 
}