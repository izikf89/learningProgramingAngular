import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
    <p *ngIf="a; else tamplateName;then tamplateThen">ng-if</p>
     <ng-template #tamplateName><h2>destroy</h2></ng-template>
     <ng-template #tamplateThen><w>d</w></ng-template>
    `,
  styles: ['h2{ color: red }']
})
export class AppComponent  {
  a = true;
  ngOnInit() { 
    setTimeout(()=> { this.a = false;}, 3000);
  }
}

@Component({
  selector: 'w',
  template: '<h1 >create</h1>',
  styles: ['h1{ color: green}']
})
export class DestroyComponent  {
  a = true;
  ngOnDestroy() {alert('ngOnDestroy play!')}
}