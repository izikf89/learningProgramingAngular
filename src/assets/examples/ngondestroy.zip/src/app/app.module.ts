import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent, DestroyComponent } from './app.component';

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent, DestroyComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
