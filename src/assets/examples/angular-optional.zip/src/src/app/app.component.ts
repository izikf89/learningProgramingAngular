import { Component, Injectable, Optional } from '@angular/core';

@Injectable()
export class OptionalS { }

@Component({
    selector: 'my-app', 
    template: '<h1> if you see me so app not break</h1>',
}) export class AppComponent {
    constructor(@Optional() service1: OptionalS) { }
}