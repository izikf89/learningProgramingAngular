import { Component } from '@angular/core';
import { trigger, style, animate, transition, state } from '@angular/animations';

@Component({
  selector: 'my-app',
  template: '<button [@state]="value" >דוגמא</button> value = {{ value }}',
  animations: [
    trigger('state',[
      state('A', style({background: 'green'})),
      state('B', style({background: 'red'})),
      transition('A=>B', [       
        animate('1s',  
          style({background: 'red'})
        )
      ]),      
      transition('B=>A', [       
        animate('1s',  
          style({background: 'green'})
        )
      ])      
    ])
  ]
})
export class AppComponent  {
  value: string = 'A';
  
  ngOnInit() {
    setInterval(()=> {
      this.value = this.value == 'A' ? 'B' : 'A';
    }, 2000);
  }
}