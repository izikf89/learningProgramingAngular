import { Component } from '@angular/core';
import { trigger, style, animate, transition, query } from '@angular/animations';

@Component({
  selector: 'my-app',
  template: `
    <div *ngIf="show" [@optional]>
      <h2 class='optional'>have optional</h2>
    </div>`,
  animations: [
    trigger('optional',[
      transition(':enter',[
        query('h1', [
          animate("1s", style({ background: "red" }))
          ], { optional: true }
        ),   
        animate('1s', style({ background: "blue"}))
      ])
    ]),
  ]
})
export class AppComponent  {
  show: boolean = true;
  
  ngOnInit() {
    setInterval(()=> {
      this.show = !this.show;
      setTimeout(()=> {
        this.show = !this.show;
      }, 0);
    }, 1000);
  }
}