import { Component } from '@angular/core';
import { trigger, style, animate, transition, query, stagger } from '@angular/animations';

@Component({
  selector: 'my-app',
  template: `
    <div [@stagger] *ngIf='show'>
      <div *ngFor="let item of items">{{ item }}</div>
    </div>`,
  animations: [
    trigger('stagger', [
      transition('* => *', [ 
        query(':enter', [
            style({ opacity: 0 }),
            stagger(1000, [animate('0.5s', style({ opacity: 1 }))])
          ], { optional: true }
        )
      ])
    ])
  ]
})
export class AppComponent  {
  items = [1,2,3,4]; 
  show = true;
  
  ngOnInit() {
    setInterval(()=> {
      this.show = !this.show;
      setTimeout(()=> {
        this.show = !this.show;
      }, 0);
    }, 4000);
  }
}




