import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<input (keyup.enter)="myMethod($event)" value="press enter here">',
})           
export class AppComponent  {
  myMethod(e) { alert(e) }
}