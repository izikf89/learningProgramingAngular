import { Component, Injectable, Host, Optional } from '@angular/core';

@Injectable()
export class Service {}

@Component({
  selector: 'my-app', 
  template: `<child></child>`,
  providers: [ Service ]
}) export class AppComponent { }

@Component({
  selector: 'child', 
  template: '<h1>{{ text }}</h1>',    
}) export class Child {
  text;
  constructor( @Host() @Optional() service: Service) { 
    this.text = (service === null);
  }
}
