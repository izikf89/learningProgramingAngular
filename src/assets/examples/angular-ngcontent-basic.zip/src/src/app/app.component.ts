import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
    <b>
      <c></c>  
    </b>
  `
})
export class AppComponent {}

@Component({
  selector: 'b',
  template: `
  <h1>before</h1>
  <ng-content></ng-content>
  <h1>after</h1>
  `,
})
export class B {}

@Component({
  selector: 'c',
  template: '<h1>content</h1>',
  
})
export class C {}

