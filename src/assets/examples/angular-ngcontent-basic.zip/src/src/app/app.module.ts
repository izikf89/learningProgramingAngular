import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent, B, C } from './app.component';

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent, B, C ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
