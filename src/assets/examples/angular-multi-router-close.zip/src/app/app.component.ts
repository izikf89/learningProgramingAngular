import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: 'my-app',
  template: 
    `<a [routerLink]='[{ outlets: { secondRouter: ["A"] } }]'>A</a>
    <a [routerLink]='[{ outlets: { secondRouter: ["B"] } }]'>B</a>

    <button (click)='close()'>close</button>

    <router-outlet name='secondRouter'></router-outlet>`,
})
export class AppComponent  {

  constructor(private router: Router) {}

  close() {
    this.router.navigate([{outlets:{secondRouter: null}}]);
  }
}

@Component({
  selector: 'app-a',
  template: '<h1>A</h1>',
})
export class AComponent  {}

@Component({
  selector: 'app-b',
  template: '<h1>B</h1>',
})
export class BComponent  {}

const routes: Routes = [
  { path: 'A', component: AComponent, outlet: 'secondRouter' },
  { path: 'B', component: BComponent, outlet: 'secondRouter' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class RootRoutingModule { }
