import { Component, Injectable, SkipSelf, Optional } from '@angular/core';

@Injectable()
export class Service {
  text = 'i service'
  }

@Component({
  selector: 'my-app', 
  template: `<child></child>`,
}) export class AppComponent { }

@Component({
  selector: 'child', 
  template: '<h1>{{ text }}</h1>',  
  providers: [ Service ]  
}) export class Child {
  text;
  constructor( @SkipSelf() @Optional() service: Service) { 
    this.text = (service === null);
  }
}
