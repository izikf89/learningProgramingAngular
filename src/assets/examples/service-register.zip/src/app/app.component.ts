import { Component, Injectable } from '@angular/core';


@Injectable()
export class ServiceCounter1S {
    counter = 0;
}

@Injectable()
export class ServiceCounter2S {
    counter = 0;
}

@Component({
    selector: 'app-child-1', 
    template: '',
    providers: [ServiceCounter2S]
}) export class Child1C {
    constructor(service1: ServiceCounter1S, service2: ServiceCounter2S) {
        service1.counter++;
        service2.counter++;
    }
}

@Component({
    selector: 'app-child-2', 
    template: 
      `<h1>{{ result1 }}</h1>
      <h1>{{ result2 }}</h1>`,
    providers: [ServiceCounter2S]
}) export class Child2C {
    result1;
    result2;
    constructor(service1: ServiceCounter1S, service2: ServiceCounter2S) {
        service1.counter++;
        service2.counter++;
        this.result1 = 'service1: ' + service1.counter;
        this.result2 = 'service2: ' + service2.counter; 
    }
}

@Component({
    selector: 'my-app', 
    template: `
        <app-child-1></app-child-1>
        <app-child-2></app-child-2>`,
}) export class AppComponent { }