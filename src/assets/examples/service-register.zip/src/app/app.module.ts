import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent, Child1C, Child2C, ServiceCounter1S, ServiceCounter2S } from './app.component';

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent, Child1C, Child2C ],
  providers:    [ ServiceCounter1S, ServiceCounter2S ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
