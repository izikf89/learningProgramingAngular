import { Component, Directive, ElementRef } from '@angular/core';

@Component({
  selector: 'my-app',
  template: 
    `<h1>yes</h1>
    <h2>yes</h2>
    <h3>yes</h3>
    <h4>not</h4>`,
})
export class AppComponent  { }

@Directive({
  selector: ':not(h4)',
})
export class MyDirective  {
    constructor(elm: ElementRef) { elm.nativeElement.style.color = 'green'; }
 }