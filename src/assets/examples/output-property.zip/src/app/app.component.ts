import { Component, EventEmitter, HostListener } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1>event - property</h1>',
  outputs: ['eventName'],  
})
export class AppComponent  {
  eventName = new EventEmitter();  

  ngOnInit(){
    this.eventName.emit('hello world');
  }

  @HostListener('eventName', ['$event'] ) myMethod(e){ 
    alert(e);
  }  
}