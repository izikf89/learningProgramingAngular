import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: 
    `<input [(ngModel)]="myProperty" type="checkbox">
    <h1>{{ myProperty }}</h1>`,
})
export class AppComponent {
  myProperty = true;
}