import { Component, Input } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<app-child [newAttribute]="'hello world'" ></app-child>`,
})
export class AppComponent  { }

@Component({
  selector: 'app-child',
  template: `<h1>{{ result }}</h1>`,
  inputs: [ 'result:newAttribute'],
})
export class ChildComponent  {
  result;
}