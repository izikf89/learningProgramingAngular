import { Component,ViewChild,ElementRef,AfterViewInit } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map'
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import {Observable} from 'rxjs/Observable';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent implements AfterViewInit {

  name = 'Angular 4';
  posts: any;
  bool = false;
  url: string = 'http://200.33.191.161:9090/reservationsapi/31922904?idHotel=2';
  @ViewChild('filter')filteru: ElementRef;


  constructor(private http : Http){
    this.http.get(this.url).map(res => res.json()).subscribe(data => {
      this.posts = data.data.children;
    });
  }

ngAfterViewInit() {
 // console.log(this.filteru.nativeElement);
      Observable.fromEvent(this.filteru.nativeElement, 'keyup') 
        .debounceTime(150)
        .distinctUntilChanged()
        .subscribe(() => {
          console.log("A");
        });
    }

}
