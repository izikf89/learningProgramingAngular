import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1 [ngStyle]="style">ng style</h1>`,
})
export class AppComponent  {
  style = {color:'blue'}
 }
