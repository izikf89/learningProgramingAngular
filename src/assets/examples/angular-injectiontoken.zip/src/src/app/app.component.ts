import { Component, Inject, InjectionToken } from '@angular/core';

const token = new InjectionToken('');

@Component({
  selector: 'my-app', 
  template: `<h1>{{ text }}</h1>`,
  providers: [{ provide: token, useValue: 'I service' }]
}) export class AppComponent {
  text;
  constructor(@Inject(token) private service) { }

  ngOnInit() {
    this.text = this.service;
  }
}