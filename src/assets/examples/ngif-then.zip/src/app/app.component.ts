 import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
    <div *ngIf="show; else elseBlock">true</div>
    <ng-template #elseBlock>else</ng-template>
`
})
export class AppComponent {
  show: boolean = true;
}