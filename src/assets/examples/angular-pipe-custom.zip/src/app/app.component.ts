import { Component, Pipe } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1> {{ chars | myPipe }} </h1>',
})
export class AppComponent  {
  chars = 1;
}

@Pipe({ name: 'myPipe' })
export class MyPipe {
  transform(value) {
    value++;
    return value * 2; 
  }
}