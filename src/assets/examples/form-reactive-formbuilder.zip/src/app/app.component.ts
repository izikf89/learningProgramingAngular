import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'my-app',
  template:`
    <form [formGroup]='formName' >
        <input formControlName='inputName'>
    </form>                      
    <p> value: {{ formName.value.inputName }}</p>
    <p> valid: {{ formName.valid }}</p>`
})
export class AppComponent {

  constructor(private fb: FormBuilder) { }

  formName = this.fb.group({
    inputName: ['default value', Validators.required]
  });
}