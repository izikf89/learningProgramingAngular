import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1 [ngClass]="classCtrl">ng class</h1>`,
  styles: [
    `.classA {
        color:red
    }
    .classB {
        background: black
    }`
  ]
})
export class AppComponent  {
  classCtrl = {
        'classA' : true,
        'classB' : true
    }
}
