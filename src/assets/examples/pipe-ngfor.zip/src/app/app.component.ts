import { Component, Pipe } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1 *ngFor="let x of (array | myPipe)">{{ x }}</h1>',
})
export class AppComponent  {
  array=[1,2,3]
}

@Pipe({ name: 'myPipe' })
export class MyPipe {
  transform(value) {
    for(let i = 0; i < value.lengeth; i++) {
      value++;
      value * 2;
    } 
    return value;
  }
}