import { Component, Directive, ElementRef } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1 class="directiveClass">tag class</h1>',
})
export class AppComponent  {}

@Directive({
  selector: '.directiveClass',
})
export class MyDirective  { 
  constructor(elm: ElementRef) { elm.nativeElement.style.color = 'red'; }
 }
