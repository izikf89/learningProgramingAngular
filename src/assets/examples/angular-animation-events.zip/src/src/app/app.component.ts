import { Component } from '@angular/core';
import { trigger, style, animate, transition } from '@angular/animations';

@Component({
  selector: 'my-app',
  template: `
  {{ event }}
  <br> 
  <button *ngIf='show' [@trigger] (@trigger.start)="displayEvent('start')" (@trigger.done)="displayEvent('done')">דוגמא</button>
  `,
  animations: [
    trigger('trigger',[
      transition(':enter',
        animate('1s',
          style({transform: 'translateX(300%)', opacity: '0'})
        )
      )
    ])
  ]
})
export class AppComponent  {
  show: boolean = true;
  event: string;

  displayEvent(value) {
    this.event = value;
  }

  ngOnInit() {
    setInterval(()=> {
      this.show = !this.show;
    } ,1000);
  }
}