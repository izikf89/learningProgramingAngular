import { Component } from '@angular/core';
import { trigger, style, animate, transition } from '@angular/animations';

@Component({
  selector: 'my-app',
  template: `<button *ngIf='show' [@simple]>דוגמא</button>`,
  animations: [
    trigger('simple',[
      transition(':enter', [
        animate('1500ms',style({background: 'red'})),
        animate('1500ms',style({background: 'blue'}))
      ])      
    ])
  ]
})
export class AppComponent  {
  show: boolean = true;
  
  ngOnInit() {
    setInterval(()=> {
      this.show = !this.show;
    } ,3000);
  }
}