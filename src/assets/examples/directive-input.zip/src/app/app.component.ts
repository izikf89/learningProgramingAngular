import { Component, Directive, Input, ElementRef } from '@angular/core';

@Directive({
  selector: '[app-color]' 
})
export class ColorDirective {
  @Input('color') color;

  constructor(private elm: ElementRef) {}
 
  ngOnInit() {   
    this.elm.nativeElement.style.color = this.color;
  }
}

@Component({
  selector: 'my-app',
  template: `<h1 app-color [color]="'red'" >directive - input</h1>`,
})
export class AppComponent { }