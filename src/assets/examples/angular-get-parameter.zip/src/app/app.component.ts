import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActivatedRoute, Router } from '@angular/router'

@Component({
  selector: 'my-app',
  template: 
    `<button (click)="navigate('A/1')">A</button>
    <button (click)="navigate('B/2')">B</button>
    <router-outlet></router-outlet>`,
})
export class AppComponent  {
  queryParams = [];

  constructor(private route: ActivatedRoute, private router: Router ) { }
  
  navigate(path) {
    this.router.navigate([path], { queryParams: {parameter: 'value1'}});

    this.queryParams=[];
    this.route.queryParams.subscribe(map => this.queryParams.push(map));

    alert( 
      'get queryParams: ' + this.route.snapshot.queryParams.parameter
      + '\n get all queryParams: ' + this.queryParams
      + '\n get url with parameter: ' + this.router.routerState.snapshot.url
    )
  }
}

@Component({
  selector: 'app-a',
  template: '<h1>A</h1>',
})
export class AComponent  {
  params = [];
  url = [];
  constructor(private route: ActivatedRoute, private router: Router ) { }

  ngOnInit() {
    this.params = [];
    this.url = [];

    this.route.params.subscribe(map => this.params.push(map));
    this.route.url.subscribe(map =>  this.url.push(map.join('')));

    alert(
      'get params: ' + this.route.snapshot.params.id
      + '\n get all params: ' + this.params
      + '\n get last navigate: ' + this.url
    );
  }
}

@Component({
  selector: 'app-b',
  template: '<h1>B</h1>',
})
export class BComponent  {
  params = [];
  url = [];
  constructor(private route: ActivatedRoute, private router: Router ) { }

   ngOnInit() {
    this.params = [];
    this.url = [];

    this.route.params.subscribe(map => this.params.push(map));
    this.route.url.subscribe(map =>  this.url.push(map.join('')));

    alert(
      'get params: ' + this.route.snapshot.params.id
      + '\n get all params: ' + this.params
      + '\n get last navigate: ' + this.url
    );
  }
}

const routes: Routes = [
  { path: 'A/:id', component: AComponent },
  { path: 'B/:id', component: BComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class RootRoutingModule { }
