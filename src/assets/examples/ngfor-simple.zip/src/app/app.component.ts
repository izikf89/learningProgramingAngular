import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<ul><li *ngFor="let x of array">{{ x }}</li></ul>',
})
export class AppComponent  {
  array = [1,2,3];
}