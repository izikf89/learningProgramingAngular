import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent, Impure, Pure } from './app.component';

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent, Impure, Pure ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
