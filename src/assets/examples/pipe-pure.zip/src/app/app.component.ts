import { Component, Pipe } from '@angular/core';

@Component({
  selector: 'my-app',
  template:
    `<h1>pure: {{ Object | purePipe }}</h1>
     <h1>impure: {{ Object | impurePipe }}</h1>
     <button (click)='fun()'>change data</button>`
})
export class AppComponent {
  Object = {value: 1};
  fun() { this.Object.value++; }
}

@Pipe({name: 'purePipe'})
export class Pure   {
  transform(item){        
    return item.value  * 2;
  }    
}

@Pipe({
  name: 'impurePipe',
  pure: false
  })
export class Impure   {
  transform(item){        
    return item.value   * 2;
  }    
}