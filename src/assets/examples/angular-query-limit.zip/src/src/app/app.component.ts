import { Component } from '@angular/core';
import { trigger, style, animate, transition, query } from '@angular/animations';

@Component({
  selector: 'my-app',
  template: `
    <div *ngIf="show" [@optional]>
      <button class='optional'>1</button>
      <button class='optional'>2</button>
      <button class='optional'>3</button>
    </div>`,
  animations: [
    trigger('optional',[
      transition(':enter',[
        query('button', [
          animate("1s", style({ background: "red" }))
          ], { limit: 2 }
        ),   
      ])
    ]),
  ]
})
export class AppComponent  {
  show: boolean = true;
  
  ngOnInit() {
    setInterval(()=> {
      this.show = !this.show;
      setTimeout(()=> {
        this.show = !this.show;
      }, 0);
    }, 1000);
  }
}