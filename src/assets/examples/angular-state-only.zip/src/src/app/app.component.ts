import { Component } from '@angular/core';
import { trigger, style, animate, transition, state } from '@angular/animations';

@Component({
  selector: 'my-app',
  template: '<button [@stateOnly]="value" >דוגמא</button> value = {{ value }}',
  animations: [
    trigger('stateOnly',[
      state('A', style({background: 'green'})),
      state('B', style({background: 'red'}))
    ])
  ]
})
export class AppComponent  {
  value: string = 'A';
  
  ngOnInit() {
    setInterval(()=> {
      this.value = this.value == 'A' ? 'B' : 'A';
    } ,1000);
  }
}