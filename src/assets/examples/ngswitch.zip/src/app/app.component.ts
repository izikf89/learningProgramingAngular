import { Component } from '@angular/core';

 @Component({
   selector: 'my-app',
   template: 
     `<div [ngSwitch]="1">
       <h1 *ngSwitchCase="1">1</h1>
       <h1 *ngSwitchCase="2">2</h1>
       <h1 *ngSwitchDefault>default</h1>    
     </div>`,
 })
 export class AppComponent  { }