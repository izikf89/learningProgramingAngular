import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent, MyDirective } from './app.component';

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent, MyDirective ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }