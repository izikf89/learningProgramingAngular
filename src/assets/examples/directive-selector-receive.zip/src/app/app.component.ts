import { Component, Directive, ElementRef } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1 recieve=value >recieve</h1>'
})
export class AppComponent  {}

@Directive({
  selector: '[recieve=value]',
})
export class MyDirective  { 
  constructor(elm: ElementRef) { elm.nativeElement.style.color = 'red'; }
}