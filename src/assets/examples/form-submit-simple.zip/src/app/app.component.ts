import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: 
    `<form #ctrl='ngForm' (submit)='fun()'>
        <input ngModel name='inputName' required>
        <input type='submit' [disabled]='!ctrl.valid'  >
    </form>
    <p> value: {{ ctrl.value.inputName }} </p>
    <p> valid: {{ ctrl.valid }} </p>`
})
export class AppComponent {
  fun() { alert('i submit'); }
 }