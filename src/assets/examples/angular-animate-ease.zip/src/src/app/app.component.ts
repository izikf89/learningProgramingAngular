import { Component } from '@angular/core';
import { trigger, style, animate, transition } from '@angular/animations';

@Component({
  selector: 'my-app',
  template: `
    <button *ngIf='show' [@noEase]>דוגמא</button>
    <br><br>
    <button *ngIf='show' [@out]>דוגמא</button>
    <br><br>
    <button *ngIf='show' [@in]>דוגמא</button>
    <br><br>
    <button *ngIf='show' [@outIn]>דוגמא</button>
    `,
  animations: [
    trigger('noEase',[
      transition(':enter', [
        style({transform: 'translateX(800%)'}),       
        animate('3s', style({transform: 'translateX(0%)'})),
      ])      
    ]), 
    trigger('out',[
      transition(':enter', [
        style({transform: 'translateX(800%)'}),       
        animate('3s  ease-out', style({transform: 'translateX(0%)'})),
      ])      
    ]),
    trigger('in',[
      transition(':enter', [
        style({transform: 'translateX(800%)'}),       
        animate('3s  ease-in', style({transform: 'translateX(0%)'})),
      ])      
    ]),
    trigger('outIn',[
      transition(':enter', [
        style({transform: 'translateX(800%)'}),       
        animate('3s  ease-in-out', style({transform: 'translateX(0%)'})),
      ])      
    ]),
  ]
})
export class AppComponent  {
  show: boolean = true;
  
  ngOnInit() {
    setInterval(()=> {
      this.show = !this.show;
      setTimeout(()=> {
        this.show = !this.show;
      } ,1);
    } ,3000);
  }
}