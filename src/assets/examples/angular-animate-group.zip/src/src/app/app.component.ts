import { Component } from '@angular/core';
import { trigger, style, animate, transition, group } from '@angular/animations';

@Component({
  selector: 'my-app',
  template: '<button *ngIf="show" [@group] >דוגמא</button>',
  animations: [
    trigger('group',[
      transition(':enter',[
        group([
            animate("1s", style({ background: "red" })),
            animate("3s", style({ transform: 'translateX(300px)' }))
        ])   
      ])
    ])
  ]
})
export class AppComponent  {
  show: boolean = true;
  
  ngOnInit() {
    setInterval(()=> {
      this.show = !this.show;
      setTimeout(()=> {
        this.show = !this.show;
      } ,1);
    } ,3000);
  }
}