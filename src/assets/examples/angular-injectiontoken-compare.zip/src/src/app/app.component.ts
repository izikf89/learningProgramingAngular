import { Component, InjectionToken, Inject } from '@angular/core';

const stringA = 'string';
const stringB = 'string';

const objectA = new InjectionToken('string');
const objectB = new InjectionToken('string');

@Component({
  selector: 'my-app', 
  template: 
    `<h1>string A - {{ string1 }}</h1>
    <h1>string B - {{ string2 }}</h1>
    <h1>object A - {{ object1 }}</h1>
    <h1>object B - {{ object2 }}</h1>`,
  providers: [ 
    { provide: stringA, useValue: 'first' }, 
    { provide: stringB, useValue: 'last' }, 
    { provide: objectA, useValue: 'first' }, 
    { provide: objectB, useValue: 'last' } 
  ]
}) export class AppComponent {
  string1;
  string2;
  object1;
  object2;
  constructor(@Inject(stringA) A, @Inject(stringB) B, @Inject(objectA) objA, @Inject(objectB) objB) { 
    this.string1 = A;
    this.string2 = B;
    this.object1 = objA;
    this.object2 = objB;
  }
}