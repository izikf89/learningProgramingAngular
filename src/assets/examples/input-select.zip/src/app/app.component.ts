import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
    <select [(ngModel)]="myProperty">
    <option *ngFor='let number of array'>{{ number }}</option>
    </select>    
    <h1>{{ myProperty }}</h1>`
})
export class AppComponent  {
  array = [1, 2, 3];
}