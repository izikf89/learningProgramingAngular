import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

/***** component ***********/
@Component({
  selector: 'app-b',
  template: '<h1>B</h1>',
})
export class MyComponent  {}

/******** router **********/
const routes: Routes = [
  { path: '', component: MyComponent }  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RootRoutingModule { }

/********* module ***********/
@NgModule({
  imports:      [ RootRoutingModule ],
  declarations: [ MyComponent ]
})
export class SecondModule { }
