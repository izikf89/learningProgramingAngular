import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

@Component({
  selector: 'my-app',
  template: `
    <a routerLink='A'>A</a>
    <a routerLink='B'>B</a>
    <router-outlet></router-outlet>`,
})
export class AppComponent { }

@Component({
  selector: 'app-a',
  template: '<h1>A</h1>',
})
export class AComponent  {}

const routes: Routes = [
  { path: 'A', component: AComponent },  
  { path: 'B', loadChildren: './lazy-loading.module#SecondModule' } 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class RootRoutingModule { }
