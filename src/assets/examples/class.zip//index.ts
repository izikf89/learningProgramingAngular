class MyClass {
  property = 1;
  method () {
    document.getElementById('app').innerText = this.property + '';
   }
}

let myClass = new MyClass();
myClass.method()
