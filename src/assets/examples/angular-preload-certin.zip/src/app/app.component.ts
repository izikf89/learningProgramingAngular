import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import 'rxjs/add/observable/of';
import { Injectable } from '@angular/core';
import { Route } from '@angular/router';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'my-app',
  template: `
    <a routerLink='A'>A</a>
    <a routerLink='B'>B</a>
    <router-outlet></router-outlet>`,
})
export class AppComponent { }

@Component({
  selector: 'app-a',
  template: '<h1>A</h1>',
})
export class AComponent  {}

@Injectable()
export class serviceName {
  preload(route: Route, load: () => Observable<any>) {
    if (route.data && route.data['preload']) {
      return load();
    } else {
      return Observable.of(null);
    }
  }
}

const routes: Routes = [
  { path: 'A', component: AComponent },  
  { path: 'B', loadChildren: './lazy-loading.module#SecondModule', data: { preload: true } } 
];

@NgModule({
  imports: [RouterModule.forRoot(
    routes,
    { enableTracing: false, preloadingStrategy: serviceName } 
  )],
  exports: [RouterModule]
})
export class RootRoutingModule { }
