import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent, AComponent, RootRoutingModule, serviceName } from './app.component';

@NgModule({
  imports:      [ BrowserModule, RootRoutingModule ],
  declarations: [ AppComponent, AComponent ],
  providers:    [ serviceName ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
