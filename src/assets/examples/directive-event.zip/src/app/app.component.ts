import { Component, Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[app-my-directive]' 
})
export class MyDirective {
  @HostListener('click', ['$event']) myMethod(e) {
    alert(e);
  }
}

@Component({
  selector: 'my-app',
  template: '<h1 app-my-directive >click me</h1>',
})
export class AppComponent { }