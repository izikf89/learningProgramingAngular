import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
    <input required [(ngModel)]="modelName" #hash=ngModel >
    <p *ngIf='hash.errors && hash.errors.required'>required</p> 
    <h1>{{ hash.valid }}</h1>
    <h1>{{ hash.touched	}}</h1>
    <h1>{{ hash.untouche }}</h1>
    <h1>{{ hash.dirty	}}</h1>
    <h1>{{ hash.pristine }}</h1>
    <h1>{{ hash.valid	}}</h1>
    <h1>{{ hash.invalid }}</h1>
    <h1>{{ hash.status }}</h1>`
})
export class AppComponent  {}