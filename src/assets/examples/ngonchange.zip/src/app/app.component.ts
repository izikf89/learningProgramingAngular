import { Component, Directive, Input, SimpleChanges } from '@angular/core';
@Component({
  selector: 'my-app',
  template: `<button [directiveListen]='counter' (click)='fun()'>ng change</button>`
})
export class AppComponent   {
  counter = 0;
  fun() { 
    this.counter++ 
  }
}

@Directive({
  selector: '[directiveListen]',
})
export class DirectiveListen {
  @Input () directiveListen;
  ngOnChanges(chg: SimpleChanges) {
    alert('i listen');  
  }
}
