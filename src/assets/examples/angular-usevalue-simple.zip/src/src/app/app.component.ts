import { Component, Inject } from '@angular/core';

let value = 'my value' ;

class Interface {}; 

@Component({
    selector: 'my-app', 
    template: '<h1>{{ text }}</h1>',
    providers: [ { provide: Interface, useValue: value } ],
}) export class AppComponent {
    text;

    constructor(myVariable: Interface) {
        this.text = myVariable;
    }
}