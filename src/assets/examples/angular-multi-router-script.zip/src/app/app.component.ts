import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: 'my-app',
  template: 
    `<a routerLink='A'>A</a>
    <a routerLink='B'>B</a>
    <br>
    <button (click)='c()'>C</button>
    <button (click)='d()'>D</button>

    <router-outlet></router-outlet>
    <router-outlet name='secondRouter'></router-outlet>`,
})
export class AppComponent  {

  constructor(private router: Router) {}

  c() { this.router.navigate([{outlets:{secondRouter: 'C'}}]); }
  d() { this.router.navigate([{outlets:{secondRouter: 'D'}}]); }
}

/***** fitst router */
@Component({
  selector: 'app-a',
  template: '<h1>A</h1>',
})
export class AComponent  {}

@Component({
  selector: 'app-b',
  template: '<h1>B</h1>',
})
export class BComponent  {}

/****** second router */

@Component({
  selector: 'app-c',
  template: '<h1>C</h1>',
})
export class CComponent  {}

@Component({
  selector: 'app-d',
  template: '<h1>D</h1>',
})
export class DComponent  {}

const routes: Routes = [
  { path: 'A', component: AComponent },
  { path: 'B', component: BComponent },
  { path: 'C', component: CComponent, outlet: 'secondRouter' },
  { path: 'D', component: DComponent, outlet: 'secondRouter' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class RootRoutingModule { }
