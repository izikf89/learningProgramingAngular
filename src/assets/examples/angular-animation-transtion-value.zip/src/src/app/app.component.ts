import { Component } from '@angular/core';
import { trigger, style, animate, transition } from '@angular/animations';

@Component({
  selector: 'my-app',
  template: `<button [@simple]='value' >דוגמא</button>`,
  animations: [
    trigger('simple',[
      transition('A <=> B',
        [
          style({transform: 'translateX(0%)', opacity: '1'}),
          animate('1s',
            style({transform: 'translateX(300%)', opacity: '0'})
          )
        ]
      )
    ])
  ]
})
export class AppComponent  {
  value = "A";
  
  ngOnInit() {
    setInterval(()=> {
      this.value = this.value == "A" ? "B" : "A";
    }, 2000);
  }
}