import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActivatedRoute, Router } from '@angular/router'

@Component({
  selector: 'my-app',
  template: 
    `<button (click)="navigate('A')">A</button>
    <button (click)="navigate('B')">B</button>
    <router-outlet></router-outlet>`,
})
export class AppComponent  {
  constructor(private route: ActivatedRoute, private router: Router ) { }
  navigate(path) {
    this.router.navigate([path]);
  }
}

@Component({
  selector: 'app-a',
  template: '<h1>A</h1>',
})
export class AComponent  {}

@Component({
  selector: 'app-b',
  template: '<h1>B</h1>',
})
export class BComponent  {}

const routes: Routes = [
  { path: 'A', component: AComponent },
  { path: 'B', component: BComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class RootRoutingModule { }
