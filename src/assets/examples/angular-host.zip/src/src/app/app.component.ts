import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template:'<p>hello world</p>',
  styles:[':host { color: red }']})
export class AppComponent  {}