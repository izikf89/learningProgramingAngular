import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'my-app',
  template:`
    <form [formGroup]='formName' >
        <input formControlName='inputName'>
    </form>                      
    <p> value: {{ formName.value.inputName }}</p>
    <p> valid: {{ formName.valid }}</p>`
})
export class AppComponent  {
  formName = new FormGroup({
    inputName: new FormControl("default value", [
      Validators.required,
      Validators.maxLength(15)
    ])
  })  
}