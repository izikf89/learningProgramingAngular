import { Component, Injector } from '@angular/core';

class MyClass { text = 'I class' }

const injector = Injector.create({providers: [{provide: MyClass, deps:[]}]});
const service = injector.get(MyClass);

alert(service.text);

@Component({
  selector: 'my-app',
  template: '',
})
export class AppComponent { }