import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1 (click)="myMethod($event)">click me</h1>',
})
export class AppComponent  {
  myMethod(e) {alert(e)}
}