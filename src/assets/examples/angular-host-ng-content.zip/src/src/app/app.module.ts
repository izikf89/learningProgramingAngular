import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent, Parent, Child } from './app.component';

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent, Parent, Child ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
