import { Component, Optional, Host } from '@angular/core';

export class Service { }

@Component({
  selector: 'my-app',
  template: 
    `<parent>
      <child></child>
    </parent>`,
})
export class AppComponent  {}

@Component({
  selector: 'parent',
  template: '<ng-content></ng-content>',
  providers: [ Service ]
})
export class Parent  {}

@Component({
  selector: 'child',
  template: '<h1>{{ text }}</h1>',
})
export class Child  {
    text;
  constructor(  @Optional() @Host() service: Service) { 
    this.text = service === null;
  }
}
