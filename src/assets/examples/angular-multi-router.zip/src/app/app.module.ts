import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent, RootRoutingModule1, RootRoutingModule2, AComponent, BComponent } from './app.component';

@NgModule({
  imports:      [ BrowserModule, RootRoutingModule1, RootRoutingModule2 ],
  declarations: [ AppComponent, AComponent, BComponent  ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
