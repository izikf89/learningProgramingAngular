import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ActivatedRoute, Router } from '@angular/router'

@Component({
  selector: 'my-app',
  template: `
    <button (click)="navigate('A/1')">A</button>
    <button (click)="navigate('B/2')">B</button>
    <router-outlet></router-outlet>`,
})
export class AppComponent  {
  queryParams = [];

  constructor(private route: ActivatedRoute, private router: Router ) { }
  
  navigate(path) {
    this.router.navigate([path], { queryParams: {parameter: 'value1'}});
  }
}

@Component({
  selector: 'app-a',
  template: `
  <h1>A</h1>
  <p> params: {{params | json}}</p>
  <p> query params: {{queryParams | json}}</p>
  <p> url: {{url}}</p>
  <p> full url: {{fullUrl}}</p>`
})
export class AComponent  {
  params;
  queryParams;
  url;
  fullUrl;

  constructor(private route: ActivatedRoute, private router: Router ) { }

  ngOnInit() {
    this.params = this.route.snapshot.params;
    this.queryParams = this.route.snapshot.queryParams;
    this.url = this.route.snapshot.url.join('');
    this.fullUrl = this.router.url;  
  }
}

@Component({
  selector: 'app-b',
  template: `
  <h1>B</h1>
  <p> params: {{params | json}}</p>
  <p> query params: {{queryParams | json}}</p>
  <p> url: {{url}}</p>
  <p> full url: {{fullUrl}}</p>`
})
export class BComponent  {
  params;
  queryParams;
  url;
  fullUrl;
  
  constructor(private route: ActivatedRoute, private router: Router ) { }

  ngOnInit() {
    this.params = this.route.snapshot.params;
    this.queryParams = this.route.snapshot.queryParams;
    this.url = this.route.snapshot.url.join('');
    this.fullUrl = this.router.url;  
  }
}

const routes: Routes = [
  { path: 'A/:id', component: AComponent },
  { path: 'B/:id', component: BComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class RootRoutingModule { }
