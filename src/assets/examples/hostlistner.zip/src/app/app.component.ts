import { Component, HostListener } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1>click me</h1>',
})
export class AppComponent  {
  @HostListener("click", ['$event'] ) myMethod(e){ 
    alert(e);
  }
}
