import { Component, Directive, ElementRef } from '@angular/core';

@Component({
  selector: 'my-app',
  template: '<h1 type=text>change-exist</h1>'
})
export class AppComponent  {}

@Directive({
  selector: '[type]',
})
export class MyDirective  { 
  constructor(elm: ElementRef) { elm.nativeElement.style.color = 'red'; }
}