import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent, RootRoutingModule, AComponent, BComponent, CComponent, DComponent } from './app.component';

@NgModule({
  imports:      [ BrowserModule, RootRoutingModule ],
  declarations: [ AppComponent, AComponent, BComponent, CComponent, DComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
