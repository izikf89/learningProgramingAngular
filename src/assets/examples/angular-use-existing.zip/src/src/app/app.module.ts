import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent, ServiceOldS, ServiceNewS } from './app.component';

@NgModule({
    declarations: [AppComponent],
    imports: [BrowserModule],
    providers: [
      ServiceNewS,
      {provide: ServiceOldS, useExisting: ServiceNewS}
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
