import {Component, Injectable} from '@angular/core';

@Injectable()
export class ServiceOldS {
  text = 'old service'
}

@Injectable()
export class ServiceNewS {
    text = 'new service'
}   

@Component({
    selector: 'my-app', 
    template: '<h1>{{ text }}</h1>'
}) export class AppComponent {
    text;
  
    constructor(private old: ServiceOldS, private newService: ServiceNewS) {
        this.newService.text = 'change value';
        this.text= this.old.text;
    }
}    
