import { Component, ViewChild } from '@angular/core';

@Component({ selector:'child-app', template:'' })
export class ChildComponent {  name = 'i am child'; }

@Component({
  selector: 'my-app',
  template: `<child-app #hashtag ></child-app>  {{ childValue }}`
})
export class AppComponent  {
  childValue;
  @ViewChild ('hashtag') viewChild;
  
  ngOnInit() { 
    this.childValue = this.viewChild.name;
  }
}